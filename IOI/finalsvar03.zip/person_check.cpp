#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <fstream>

using namespace std;

const int MAX_DIF=5;
const int LEN=10;

int main()
{
	ifstream in("person.in"),out("person.out");
	if (!in.is_open()) { cerr << "Hittar inte person.in!" << endl; exit(-1); }
	if (!out.is_open()) { cerr << "Hittar inte person.out!" << endl; exit(-1); }
	
	vector< vector<int> > cnt;
	for(int i=1,p=10;i<=MAX_DIF;i++,p*=10)
		cnt.push_back(vector<int>(p,0));
	vector<string> no;

	int n;
	in >> n;
	for(int i=0;i<n;i++) {
		string s;
		in >> s;
		no.push_back(s);
		set<string> v;
		for(int dif=0;dif<MAX_DIF;dif++)
			for(int j=0;j<LEN-dif;j++)
				v.insert(string(&s[j],&s[j+dif+1]));
		for(set<string>::iterator j=v.begin();j!=v.end();j++)
			cnt[j->size()-1][atoi(j->c_str())]++;
	}
	
	for(int i=0;i<n;i++) {
		string t;
		out >> t;
		bool ok=false,done=false;
		for(int dif=0;dif<MAX_DIF && !done;dif++)
			for(int j=0;j<LEN-dif && !ok;j++) {
				string s=string(&no[i][j],&no[i][j+dif+1]);
				if (cnt[dif][atoi(s.c_str())]==1) {
					done=true;
					if (s==t)
						ok=true;
				}
			}
		if (!done) {
			cerr << i+2 << " " << no[i] << ": Saknar l�sning!" << endl;
			exit(-1);
		}
		if (!ok) {
			cout << "WRONG ANSWER" << endl;
			exit(-1);
		}
	}
	cout << "ACCEPTED" << endl;	
	return 0;
}
